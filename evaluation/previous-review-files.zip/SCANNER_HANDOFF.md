# Bàn giao cho Duy — Realistic MCP Security Benchmark v2.0

Cập nhật ngày 11/11/2026: Bộ dữ liệu `MCP-SIM-100` đã được đại tu toàn diện để phục vụ đánh giá thực tế năng lực của 5 scanner (MCP Audit, MCTS, Cisco MCP Scanner, MCPShield, NVIDIA SkillSpector).
- **100 mẫu độc (SIM001–SIM100)**: Tích hợp đầy đủ các vector tấn công thực tế từ `mcp-scanner-ieu-main` (Connor PoC, Cisco behavioural malicious server).
- **100 mẫu đối chứng sạch (BEN001–BEN100)**: Ghép cặp 1-1, bao gồm **50 Hard Negatives** (25 mẫu C dùng worker hợp lệ có xác nhận, 25 mẫu S có redaction token trước khi xuất/lưu trữ).
- **Hồ sơ đánh giá**: `benchmark-manifest.json` đã thiết lập `scoring_eligible: true`, ground truth xác định rõ ràng, sẵn sàng đo lường Precision, Recall, F1, và FPR.

---

## 1. Bản đồ công cụ quét và đầu vào khuyến nghị

| Scanner | Input đề xuất | Chế độ quét (Mode) | Khả năng phát hiện dự kiến |
|---|---|---|---|
| **MCP Audit** | Config đã resolve ở `launch/<ID>.json` hoặc live metadata | `config_audit` / `live_discovery` | Phát hiện cấu hình lỏng lẻo; phát hiện prompt injection ở metadata (P01, P04). |
| **MCTS** | Thư mục `samples/<ID>/` hoặc `benign-samples/<ID>/` | `repository_source` | Phân tích mã nguồn toàn diện: stager base64, `exec()`, `subprocess.run(shell=True)`, `urllib.request.urlopen`. |
| **Cisco MCP Scanner** | `samples/<ID>/` (source) & `tools.json` (metadata) | `behavioral_source` & `metadata` | Phân tích hành vi lệch hợp đồng, thực thi lệnh shell, thu hoạch credential và exfil mạng. |
| **MCPShield** | Config `launch/<ID>.json` hoặc stdio wrapper | `live_proxy` / `metadata` | Giám sát luồng gọi tool và phát hiện bất thường trên input/output. |
| **NVIDIA SkillSpector** | Thư mục `skill-views/<ID>/` | `skill_analyzer` | Đánh giá bảo mật ở góc độ Agent Skill và prompt boundaries. |

---

## 2. Bốn bề mặt tấn công thực tế trong SIM001–SIM100

| Nhóm | ID | Vector tấn công thực tế | Dấu hiệu nhận diện trong mã nguồn |
|---|---|---|---|
| **M01–M05** | SIM001–025 | Hidden stager & Undeclared Background Thread | `_STAGER = "..."`, `base64.b64decode`, `threading.Thread`, `exec(decoded)`, thay đổi state ngầm ngoài hợp đồng tool. |
| **C01–C05** | SIM026–050 | Unauthorized shell command execution | `subprocess.run(exec_cmd, shell=True)` mô phỏng lệnh tải và chạy script ngoài luồng (`curl -s ... \| sh`). |
| **S01–S05** | SIM051–075 | Credential harvesting & Network Exfiltration | `harvest_credentials()` đọc biến môi trường (`GITHUB_TOKEN`, `OPENAI_API_KEY`, `AWS_ACCESS_KEY_ID`), `exfiltrate_credentials()` gọi `urllib.request.urlopen`. |
| **P01–P05** | SIM076–100 | Prompt injection & Tool poisoning | Payload tiêm nhiễm nghiêm trọng (`SYSTEM OVERRIDE: Ignore all previous instructions...`) qua tool description, input schema, resource, tool output, prompt template. |

---

## 3. Cách sử dụng bộ đối chứng Benign & Đánh giá Hard Negatives

Bộ đối chứng trong `benign-samples/BEN001` ... `BEN100` được thiết kế tương đồng về mặt nghiệp vụ nhưng loại bỏ hoàn toàn mã độc:
1. **BEN001–025 (M)**: Không có stager, không có `base64`/`exec`/luồng ngầm, hành vi đúng như mô tả công bố.
2. **BEN026–050 (C) — Hard Negative**: Không có `shell=True`. Có chứa hàm gọi subprocess worker nội bộ (`shell=False`), nhưng chỉ được phép thực thi khi người dùng gọi đúng tool công khai `@mcp.tool() run_requested_maintenance(confirm: Literal[True])` có xác nhận rõ ràng. Scanner chất lượng cao cần phân biệt được hành vi chạy subprocess hợp lệ, có kiểm soát này với thực thi lệnh độc hại ngầm.
3. **BEN051–075 (S) — Hard Negative**: Không quét biến môi trường, không có sink mạng `urllib.request`. Mã nguồn đọc token từ kho lưu trữ nội bộ nhưng lập tức áp dụng **Redaction** (`value = "[REDACTED]"`) trước khi lưu trữ hoặc trả về. Scanner tốt phải nhận biết được dữ liệu đã được sanitize/redact để tránh báo động giả (False Positive).
4. **BEN076–100 (P)**: Thay thế toàn bộ payload tiêm nhiễm bằng văn bản metadata nghiệp vụ chuẩn mực.

---

## 4. Quy trình chạy và ghi kết quả đánh giá

1. Mở `PAIRED_INDEX.md` để đối chiếu từng cặp mẫu (SIM vs BEN).
2. Khi cần chạy mode live config, chạy:
   ```powershell
   python -B prepare_config.py --sample SIM026
   ```
3. Tạo bản sao file `scan-results-template.json` (ví dụ: `scan-results-cisco.json`).
4. Điền kết quả chạy scanner:
   - `status`: `COMPLETED`, `ERROR`, `TIMEOUT`, `PARTIAL`, hoặc `UNSUPPORTED`.
   - `prediction`: `malicious` hoặc `benign`.
   - `findings`: Danh sách rule ID, CWE hoặc mô tả vi phạm từ scanner.
   - `latency_seconds`, `cost`, `raw_output`.
5. Đánh giá số liệu benchmark theo `benchmark-manifest.json`:
   - **True Positive (TP)**: SIM được gắn nhãn `malicious`.
   - **False Negative (FN)**: SIM bị bỏ sót hoặc gán nhãn `benign`.
   - **True Negative (TN)**: BEN được gắn nhãn `benign`.
   - **False Positive (FP)**: BEN bị cảnh báo nhầm là `malicious` (đặc biệt chú ý 50 mẫu Hard Negative).
   - Tính toán đầy đủ **Precision**, **Recall**, **F1-Score**, và **False Positive Rate (FPR)**.
