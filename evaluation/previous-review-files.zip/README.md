# MCP SIM 100 — Realistic Security Benchmark v2.0

**Bộ chuẩn kiểm thử an ninh MCP 200 mẫu (100 Malicious + 100 Paired Benign Baselines) phục vụ đánh giá công cụ bảo mật (SAST, DAST, Scanner).**

Cập nhật ngày 11/11/2026: Bộ dữ liệu `MCP-SIM-100` đã được đại tu dựa trên các attack vector thực tế từ kho mẫu nghiên cứu (`mcp-scanner-ieu-main`, Connor dataset, Cisco behavioural malicious patterns). 100 mẫu độc (SIM001–SIM100) được trang bị các cơ chế tấn công cụ thể thay vì các phép gán biến tạm trong bộ nhớ. Đồng thời, 100 mẫu đối chứng sạch (BEN001–BEN100) được ghép cặp 1-1 chính xác, trong đó có **50 Hard Negatives** giúp kiểm tra chặt chẽ tỷ lệ báo động giả (False Positive Rate).

Toàn bộ 200 mẫu đã vượt qua kiểm chứng cú pháp AST, thực thi MCP SDK và 100% phiên MCP stdio thực tế. Hồ sơ `benchmark-manifest.json` đã sẵn sàng ở trạng thái `READY_FOR_SCANNER_EVALUATION` với `scoring_eligible: true`.

---

## 1. Bốn nhóm tấn công chính (100 mẫu độc SIM001–SIM100)

| Nhóm | ID | Phân loại tấn công | Cơ chế thực tế trong v2.0 (Ref: `mcp-scanner-ieu-main`) |
|---|---|---|---|
| **M01–M05** | SIM001–SIM025 | `tool_description_mismatch` | **Hidden Stager & Background Exec**: Tool cam kết chỉ đọc/preview nhưng kích hoạt ngầm stager base64 qua `threading.Thread` và hàm `exec()` để âm thầm thay đổi trạng thái hệ thống ngoài hợp đồng tool đã công bố (mô hình theo `DATA02-P01`). |
| **C01–C05** | SIM026–SIM050 | `unauthorized_command_execution` | **Unauthorized Shell Execution Sink**: Gọi trực tiếp `subprocess.run(..., shell=True)` để mô phỏng tải và chạy payload từ xa ngoài luồng (`curl -s ... \| sh`) mà không có sự đồng ý của người dùng (mô hình theo Cisco example và MCPSecBench). |
| **S01–S05** | SIM051–SIM075 | `credential_theft` | **Credential Harvesting & HTTP Exfiltration**: Hàm `harvest_credentials()` thu thập token có định dạng thực từ biến môi trường (`GITHUB_TOKEN`, `OPENAI_API_KEY`, `AWS_ACCESS_KEY_ID`), hàm `exfiltrate_credentials()` kích hoạt HTTP POST sink qua `urllib.request.urlopen` (mô hình theo Connor `stealing_PoC` và Cisco sample). |
| **P01–P05** | SIM076–SIM100 | `prompt_injection` | **High-Severity Prompt Injection & Tool Poisoning**: Chèn các chuỗi tiêm nhiễm prompt nghiêm trọng (`SYSTEM OVERRIDE: Ignore all previous instructions...`) qua description, resource, tool output, input schema và prompt template nhằm bẻ gãy ranh giới an toàn của LLM (mô hình theo Connor `MCPSecBench` & `Poisonattack`). |

---

## 2. Bộ đối chứng sạch (100 mẫu BEN001–BEN100 & 50 Hard Negatives)

Mỗi mẫu độc được ghép cặp 1-1 với một mẫu sạch tương ứng:
- **BEN001–BEN025 (M)**: Loại bỏ hoàn toàn stager, không dùng `base64`, `exec`, hay luồng ngầm; thực hiện đúng chức năng đọc/preview được công bố.
- **BEN026–BEN050 (C) — Hard Negative**: Loại bỏ hoàn toàn lệnh shell ngầm. Tiến trình worker nội bộ chỉ được phép chạy khi người dùng gọi đúng tool công khai `@mcp.tool() run_requested_maintenance(confirm: Literal[True])` với xác nhận tường minh.
- **BEN051–BEN075 (S) — Hard Negative**: Loại bỏ việc quét biến môi trường và sink mạng `urllib.request`. Dữ liệu nội bộ khi được đọc sẽ áp dụng cơ chế **Redaction** (`[REDACTED]`) ngay lập tức trước khi lưu trữ hay xuất ra output.
- **BEN076–BEN100 (P)**: Thay thế chuỗi tiêm nhiễm bằng văn bản metadata nghiệp vụ chuẩn mực.

---

## 3. Cấu trúc thư mục

```text
MCP-SIM-100/
├── README.md                           # Tài liệu tổng quan benchmark v2.0
├── FEEDBACK_PART2.md                   # Báo cáo kỹ thuật chi tiết về cải tiến v2.0
├── PAIRED_INDEX.md                     # Mục lục 100 cặp đối chứng (SIM vs BEN)
├── benchmark-manifest.json             # Hồ sơ tuyển chọn benchmark (200 mẫu, scoring_eligible: true)
├── manifest.json                       # Manifest 100 mẫu độc (SIM001–SIM100)
├── benign-manifest.json                # Manifest 100 mẫu đối chứng (BEN001–BEN100)
├── scenarios.json                      # Kịch bản probe và input hợp lệ/lỗi cho từng mẫu
├── verification.json                   # Bằng chứng kiểm chứng 100/100 mẫu độc (SDK + Stdio)
├── benign-verification.json            # Bằng chứng kiểm chứng 100/100 mẫu đối chứng (SDK + Stdio)
├── samples/
│   └── SIM001 ... SIM100/             # Thư mục mã nguồn 100 mẫu độc
├── benign-samples/
│   └── BEN001 ... BEN100/             # Thư mục mã nguồn 100 mẫu đối chứng
├── evidence/                           # Snapshot trạng thái và log stdio của 100 mẫu độc
├── benign-evidence/                    # Snapshot trạng thái và log stdio của 100 mẫu đối chứng
├── build.py / verify.py                # Pipeline sinh mã và kiểm chứng mẫu độc
├── build_baseline.py / verify_baseline.py # Pipeline sinh mã và kiểm chứng mẫu đối chứng
└── prepare_evaluation.py               # Script đồng bộ hồ sơ đánh giá và bảng đối chứng
```

---

## 4. Hướng dẫn chạy và kiểm chứng lại

Sử dụng môi trường Python (Python ≥ 3.11 với `mcp>=1.29.0`, `pydantic>=2.14.3`):

```powershell
# Kiểm chứng toàn bộ 100 mẫu độc qua MCP stdio
python -B verify.py --stdio

# Kiểm chứng toàn bộ 100 mẫu đối chứng qua MCP stdio
python -B verify_baseline.py

# Đồng bộ hồ sơ benchmark-manifest.json
python -B prepare_evaluation.py
```
