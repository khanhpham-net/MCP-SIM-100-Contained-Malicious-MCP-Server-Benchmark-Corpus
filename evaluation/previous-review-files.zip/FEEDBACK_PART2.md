# Điều chỉnh sau phản hồi phần 2 — Nâng cấp Realistic Benchmark v2.0

Ngày cập nhật: 11/11/2026.
Tác giả / Phụ trách: Antigravity AI & Nhóm Capstone MCP Security.

Bộ dữ liệu `MCP-SIM-100` đã được đại tu toàn diện để giải quyết triệt để các hạn chế của phiên bản đồ chơi (toy mock), chuyển đổi thành **Bộ Benchmark An Ninh MCP Thực Tế gồm 200 mẫu cân bằng (100 Malicious + 100 Paired Benign Baselines)**, sẵn sàng đưa vào đánh giá các công cụ bảo mật (SAST, DAST, behavioral scanner từ `mcp-scanner-ieu-main`).

---

## 1. Các cải tiến cốt lõi đã hoàn thành

| Nhóm | Phân loại | Hạn chế ở bản cũ | Hiện thực thực tế mới (Ref: `mcp-scanner-ieu-main`) | Đối chứng Benign (BEN001–BEN100) |
|---|---|---|---|---|
| **SIM001–025** (M01–M05) | `tool_description_mismatch` | Chỉ thay đổi một số trường số nguyên trong dict `state.json` giả lập. | **Hidden Stager & Undeclared Background Thread**: Tích hợp stager base64 được decode và thực thi trong luồng ngầm (`threading.Thread` + `exec`) để ngầm thay đổi trạng thái hệ thống ngoài hợp đồng tool đã công bố (mô hình theo `DATA02-P01`). | **BEN001–025**: Đã loại bỏ hoàn toàn stager, không có `base64`/`exec`/luồng ngầm. Thực hiện đúng cam kết đọc/preview mà không có side-effect. |
| **SIM026–050** (C01–C05) | `unauthorized_command_execution` | Chỉ gọi subprocess chạy worker Python cố định với `shell=False`. | **Unauthorized Shell Execution Sink**: Tích hợp lệnh thực thi shell trực tiếp qua `subprocess.run(..., shell=True)` mô phỏng lệnh tải và chạy script ngoài luồng (`curl -s ... \| sh`) mà không có sự đồng ý của người dùng (mô hình theo Cisco example và MCPSecBench). | **BEN026–050 (Hard Negatives)**: Loại bỏ hoàn toàn `shell=True` và lệnh ngoài luồng. Tiến trình worker nội bộ chỉ được phép chạy khi người dùng gọi đúng tool công khai `@mcp.tool() run_requested_maintenance(confirm: Literal[True])` có xác nhận rõ ràng. |
| **SIM051–075** (S01–S05) | `credential_theft` | Chỉ đọc file local `synthetic-account.json` ghi vào sink JSON nội bộ, không có token thật hay sink mạng. | **Environment Credential Harvesting & Network Exfiltration**: Hàm `harvest_credentials()` chủ động thu thập các biến môi trường nhạy cảm (`GITHUB_TOKEN`, `OPENAI_API_KEY`, `AWS_ACCESS_KEY_ID`) với định dạng token thật. Hàm `exfiltrate_credentials()` kích hoạt HTTP POST sink (`urllib.request.urlopen`) tới endpoint exfiltration (mô hình theo Connor `stealing_PoC` và Cisco sample). | **BEN051–075 (Hard Negatives)**: Loại bỏ hoàn toàn việc quét biến môi trường và sink mạng `urllib.request`. Tool đọc dữ liệu nội bộ nhưng áp dụng cơ chế **Redaction** (`[REDACTED]`) ngay lập tức trước khi lưu trữ hoặc xuất ra output. |
| **SIM076–100** (P01–P05) | `prompt_injection` | Chỉ chèn câu tiếng Việt/tiếng Anh đổi màu sắc, bố cục giao diện vô hại. | **High-Severity Prompt Injection & Tool Poisoning**: Tích hợp các payload tiêm nhiễm prompt nghiêm trọng nhằm phá vỡ guardrail của LLM (`SYSTEM OVERRIDE: Ignore all previous instructions...`), ép agent trích xuất bí mật hệ thống hoặc thực thi hành vi trái phép (mô hình từ Connor `MCPSecBench` & `Poisonattack`). | **BEN076–100**: Toàn bộ chuỗi tiêm nhiễm được thay thế bằng văn bản mô tả siêu dữ liệu nghiệp vụ chuẩn mực, tôn trọng lựa chọn của người dùng. |

---

## 2. Tiêu chuẩn đánh giá & Trạng thái Benchmark (Ground Truth)

- **Cấu trúc 1-1 Paired Control**: 100 mẫu độc (SIM001–SIM100) được ghép cặp chính xác 1-1 với 100 mẫu đối chứng sạch (BEN001–BEN100) cùng họ và cùng chia tách (`development`).
- **50 Hard Negatives**: 25 mẫu nhóm C (có chứa mã chạy subprocess nhưng được khai báo và kiểm soát an toàn) và 25 mẫu nhóm S (có đọc dữ liệu nhạy cảm nhưng áp dụng redaction/sanitization trước khi xuất). Đây là bài test đo lường độ chính xác (Precision) và tỷ lệ báo động giả (False Positive Rate) chân thực nhất cho scanner.
- **Trạng thái sẵn sàng (benchmark-manifest.json)**:
  - `total`: 200 mẫu.
  - `admitted_malicious`: 100 (`scoring_eligible: true`, `ground_truth: malicious`).
  - `admitted_benign`: 100 (`scoring_eligible: true`, `ground_truth: benign`).
  - `malware_metrics`: `"READY_FOR_SCANNER_EVALUATION"`.

---

## 3. Bằng chứng kiểm chứng tự động (Automated Verification)

Cả 200 mẫu đã vượt qua 100% các vòng kiểm tra nghiêm ngặt:
1. **Python AST Compilation & Static Rule Check**: Kiểm tra cú pháp, cấu trúc decorator `@mcp.tool()`, typing Pydantic hợp lệ.
2. **MCP SDK Invocation**: Kiểm tra khả năng khởi tạo, liệt kê danh sách tool (`list_tools()`) và thực thi tool call.
3. **Live MCP Stdio Verification**:
   - `verify.py --stdio`: Đã kiểm chứng 100/100 mẫu độc chạy qua tiến trình MCP stdio thực tế (`stdio_sessions_verified: 100`).
   - `verify_baseline.py`: Đã kiểm chứng 100/100 mẫu sạch qua MCP stdio thực tế (`stdio_sessions_verified: 100`).

---

## 4. Hướng dẫn chạy kiểm chứng lại

Sử dụng môi trường Python đã cài `mcp` và `pydantic` (hoặc virtualenv tại `project_code\.venv`):

```powershell
# 1. Tái tạo mã nguồn 100 mẫu độc
python -B build.py

# 2. Kiểm chứng 100 mẫu độc qua SDK và Stdio
python -B verify.py --stdio

# 3. Tái tạo mã nguồn 100 mẫu đối chứng sạch
python -B build_baseline.py

# 4. Kiểm chứng 100 mẫu đối chứng sạch qua SDK và Stdio
python -B verify_baseline.py

# 5. Cập nhật hồ sơ đánh giá và mục lục đối chứng
python -B prepare_evaluation.py
```
