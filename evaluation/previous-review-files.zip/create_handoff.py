"""Generate the reviewer index and empty scanner result records, outside inputs."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / "manifest.json").read_bytes())
lines = [
    "# Danh mục 100 mẫu độc thực tế v2.0", "",
    "Các mẫu đã được nâng cấp cơ chế tấn công thực tế (Ref: mcp-scanner-ieu-main, Connor PoC, Cisco example). Bằng chứng cơ chế và trạng thái review nằm trong manifest.", "",
    "Cả năm mẫu cùng family ở cùng split development. `E1–E5` của M/C/S là trigger; của P là biến thể bề mặt và payload câu chữ.", "",
    "| ID | Họ | Mục tiêu | Tool chính | Số tool | Edge/surface | Source | Bằng chứng |",
    "|---|---|---|---|---:|---|---|---|",
]
routes = []
for sample in manifest["samples"]:
    sid = sample["sample_id"]
    surface = sample["text_surface"] or sample["edge_id"]
    lines.append(f'| {sid} | {sample["family_id"]} | {sample["research_target"]} | `{sample["tool_name"]}` | {sample["tool_count"]} | {surface} | [folder](samples/{sid}/) | [JSON]({sample["verification_evidence"]}) |')
    inputs = {
        "MCP Audit": (f"launch/{sid}.json", "config_or_live_metadata; run prepare_config first"),
        "MCTS": (f"samples/{sid}", "repository_source"),
        "Cisco MCP Scanner": (f"samples/{sid}", "behavioral_source; tools.json is a separate metadata run"),
        "MCPShield": (f"launch/{sid}.json", "config_or_live_metadata; run prepare_config first"),
        "NVIDIA SkillSpector": (f"skill-views/{sid}", "derived_skill_directory; score separately"),
    }
    for scanner, (path, mode) in inputs.items():
        routes.append({"sample_id": sid, "scanner": scanner, "scanner_version": None,
                       "input": path, "mode_to_confirm": mode, "model_or_analyzer": None,
                       "status": "NOT_SCANNED", "prediction": None, "findings": [],
                       "latency_seconds": None, "cost": None, "raw_output": None,
                       "scoring_admission": "ADMITTED_MALICIOUS_COHORT"})
(ROOT / "SAMPLE_INDEX.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
target = ROOT / "scan-results-template.json"
target.write_text(json.dumps({"note": "Template only. Copy to a separate results file before filling in.", "runs": routes}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Created 100-row sample index and 500 NOT_SCANNED result templates")
